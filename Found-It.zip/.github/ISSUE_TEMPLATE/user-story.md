---
name: USER STORY
about: This is our default user story template
title: USER STORY
labels: ''
assignees: ''

---

---
name: User Story
about: User Story details
title: ''
labels: ''
assignees: ''

---

As a **role** I can **capability** so that **received benefit**


***Acceptance Criteria

-Acceptance Criteria 1
-Acceptance Criteria 2
-Acceptance Criteria 3
